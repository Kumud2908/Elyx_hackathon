import React, { useEffect, useState } from "react";
import EventList from "./components/EventList";
import EventDetail from "./components/EventDetail";

export default function App() {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);

  // Fetch all events
  useEffect(() => {
    fetch("http://localhost:5000/events") // Adjust port if different
      .then(res => res.json())
      .then(data => setEvents(data))
      .catch(err => console.error("Error fetching events:", err));
  }, []);

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Elyx Member Journey</h1>
      {!selectedEvent ? (
        <EventList events={events} onSelect={setSelectedEvent} />
      ) : (
        <EventDetail event={selectedEvent} onBack={() => setSelectedEvent(null)} />
      )}
    </div>
  );
}
