import React from "react";

export default function EventList({ events, onSelect }) {
  return (
    <div>
      <h2>Events</h2>
      {events.length === 0 && <p>No events found.</p>}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {events.map(event => (
          <li
            key={event._id}
            style={{
              padding: "10px",
              borderBottom: "1px solid #ccc",
              cursor: "pointer"
            }}
            onClick={() => onSelect(event)}
          >
            <strong>{event.title}</strong> — {new Date(event.date).toLocaleDateString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
