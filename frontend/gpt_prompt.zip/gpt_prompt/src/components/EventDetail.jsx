import React, { useEffect, useState } from "react";

export default function EventDetail({ event, onBack }) {
  const [why, setWhy] = useState("");
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    // Fetch reason why
    fetch(`http://localhost:5000/why/${event._id}`)
      .then(res => res.json())
      .then(data => setWhy(data.reason || "No explanation found."))
      .catch(err => console.error(err));

    // Fetch related messages
    fetch(`http://localhost:5000/messages/${event._id}`)
      .then(res => res.json())
      .then(data => setMessages(data))
      .catch(err => console.error(err));
  }, [event._id]);

  return (
    <div>
      <button onClick={onBack} style={{ marginBottom: "10px" }}>⬅ Back</button>
      <h2>{event.title}</h2>
      <p><strong>Date:</strong> {new Date(event.date).toLocaleString()}</p>
      <p><strong>Why:</strong> {why}</p>
      <h3>Messages</h3>
      {messages.length === 0 && <p>No messages found.</p>}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {messages.map(msg => (
          <li
            key={msg._id}
            style={{
              padding: "5px",
              marginBottom: "5px",
              border: "1px solid #ccc",
              borderRadius: "5px",
              backgroundColor: msg.senderType === "Member" ? "#e1f5fe" : "#f3e5f5"
            }}
          >
            <strong>{msg.senderType}:</strong> {msg.content}
          </li>
        ))}
      </ul>
    </div>
  );
}
