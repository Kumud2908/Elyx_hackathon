import express from "express";
import Event from "../models/events.js";
import { getMessagesAroundEvent } from "../services/retrievalServices.js";
import { askLLM } from "../services/llmService.js";

const router = express.Router();

router.get("/:event_id", async (req, res) => {
  try {
    const event = await Event.findById(req.params.event_id);
    if (!event) return res.status(404).json({ error: "Event not found" });

    const messages = await getMessagesAroundEvent(event);
    const formattedMessages = messages.map(m => `[${m.timestamp.toISOString()}] ${m.sender}: ${m.content}`).join("\n");

    const prompt = [
      { role: "system", content: "You are a health assistant that explains why an event happened using only the given messages and providing exact timestamp references." },
      { role: "user", content: `Messages:\n${formattedMessages}\n\nTask:\n1. State the reason for the event.\n2. Identify the initiator.\n3. List exact message references.` }
    ];

    const summary = await askLLM(prompt);
    res.json({ event_id: event._id, summary });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
