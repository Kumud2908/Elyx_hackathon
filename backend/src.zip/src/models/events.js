import mongoose from "mongoose";

const eventSchema = new mongoose.Schema({
  timestamp: Date,
  type: String, // 'plan_change', 'diagnostic', etc.
  description: String
});

export default mongoose.model("Event", eventSchema);
