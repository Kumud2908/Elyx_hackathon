import mongoose from "mongoose";

const messageSchema = new mongoose.Schema({
  timestamp: Date,
  sender: String,
  role: String, // 'member' or 'elyx'
  content: String
});

export default mongoose.model("Message", messageSchema);
