import express from "express";
import dotenv from "dotenv";
import { connectDB } from "./config/db.js";
import whyRoutes from "./routes/why.js";

dotenv.config();
connectDB();

const app = express();
app.use(express.json());

app.use("/why", whyRoutes);

export default app;
